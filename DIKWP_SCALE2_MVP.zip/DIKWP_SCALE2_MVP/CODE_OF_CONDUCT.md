# Code of Conduct

Contributors must engage respectfully, preserve minority and local-context objections, disclose conflicts of interest, and avoid presenting synthetic demonstration results as real infrastructure performance.

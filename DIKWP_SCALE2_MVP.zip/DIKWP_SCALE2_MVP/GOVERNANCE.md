# Governance

DIKWP-SCALE² should be governed by separate maintainers for semantic runtime, infrastructure adapters, resource telemetry, data sovereignty, energy metrics and public-interest allocation. A single vendor must not control the schemas, reference scheduler, conformance suite and allocation certification process.

Changes to hard constraints or object schemas require an RFC, two independent implementation reviews and a migration path. Local nodes retain deployment authority; shared evidence does not transfer authority.

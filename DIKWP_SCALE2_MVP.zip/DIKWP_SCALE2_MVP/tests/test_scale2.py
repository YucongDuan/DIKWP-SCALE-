from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from scale2.catalog import load_models, load_resources
from scale2.mesh import TRANSFORMATIONS, coverage
from scale2.planner import baseline_plan, pareto_frontier, plan_workload
from scale2.simulation import run_demo
from scale2.workloads import generate_workloads


class Scale2Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = Path(__file__).resolve().parents[1]
        cls.resources = load_resources(cls.root / "config" / "resources.json")
        cls.models = load_models(cls.root / "config" / "models.json")
        cls.workloads = generate_workloads(40, 50721)

    def test_full_mesh_coverage(self):
        self.assertEqual(len(TRANSFORMATIONS), 25)
        self.assertEqual(coverage()["coverage"], 1.0)

    def test_workload_generation_deterministic(self):
        a = generate_workloads(5, 123)
        b = generate_workloads(5, 123)
        self.assertEqual([x.to_dict() for x in a], [x.to_dict() for x in b])

    def test_scenario_handle_not_required_for_planning_logic(self):
        w = self.workloads[0]
        r = plan_workload(w, self.models, self.resources)
        self.assertIn(r.status, {"ALLOCATED", "HOLD_FOR_REVIEW", "UNSCHEDULABLE"})

    def test_pareto_plans_have_no_hard_failures(self):
        r = plan_workload(self.workloads[2], self.models, self.resources)
        self.assertTrue(all(not p.hard_failures for p in r.pareto_plans))

    def test_allocated_plan_meets_semantic_budget(self):
        for w in self.workloads:
            r = plan_workload(w, self.models, self.resources)
            if r.chosen_plan:
                self.assertLessEqual(r.chosen_plan.semantic_loss, w.semantic_degradation_budget + 1e-9)
                self.assertGreaterEqual(r.chosen_plan.semantic_fidelity, w.min_semantic_fidelity - 1e-9)

    def test_data_residency_for_high_privacy(self):
        for w in self.workloads:
            r = plan_workload(w, self.models, self.resources)
            if r.chosen_plan and w.privacy_sensitivity >= 0.8:
                node = next(n for n in self.resources if n.node_id == r.chosen_plan.node_id)
                self.assertIn(node.region, w.data_regions)

    def test_time_flexible_uses_low_carbon_hour(self):
        for w in self.workloads:
            if w.time_flexible:
                r = plan_workload(w, self.models, self.resources)
                if r.chosen_plan:
                    node = next(n for n in self.resources if n.node_id == r.chosen_plan.node_id)
                    self.assertEqual(r.chosen_plan.execution_hour, min(range(24), key=lambda h: node.carbon_intensity_by_hour[h]))

    def test_fallback_is_different(self):
        for w in self.workloads:
            r = plan_workload(w, self.models, self.resources)
            if r.chosen_plan and r.fallback_plan:
                self.assertTrue(r.fallback_plan.node_id != r.chosen_plan.node_id or r.fallback_plan.model_id != r.chosen_plan.model_id)

    def test_uax_residuals_preserved(self):
        r = plan_workload(self.workloads[0], self.models, self.resources)
        self.assertGreaterEqual(len(r.uax_residuals), 1)

    def test_mesh_path_not_linear_only(self):
        r = plan_workload(self.workloads[0], self.models, self.resources)
        self.assertIn("P->D", r.mesh_transformations)
        self.assertIn("D->P", r.mesh_transformations)
        self.assertIn("P->P", r.mesh_transformations)

    def test_baseline_can_expose_policy_violation(self):
        seen = False
        for w in self.workloads:
            p = baseline_plan(w, self.models, self.resources, "cost_only")
            if p and p.hard_failures:
                seen = True
                break
        self.assertTrue(seen)

    def test_no_single_score_in_candidate(self):
        r = plan_workload(self.workloads[2], self.models, self.resources)
        if r.chosen_plan:
            self.assertFalse(hasattr(r.chosen_plan, "score"))

    def test_demo_outputs(self):
        with tempfile.TemporaryDirectory() as td:
            result = run_demo(self.root, td, 24, 7)
            self.assertEqual(result["metrics"]["workloads"], 24)
            self.assertTrue((Path(td) / "metrics.json").exists())
            self.assertTrue((Path(td) / "RUN_PROOF.json").exists())

    def test_run_proof_hashes(self):
        with tempfile.TemporaryDirectory() as td:
            run_demo(self.root, td, 8, 11)
            proof = json.loads((Path(td) / "RUN_PROOF.json").read_text())
            self.assertEqual(proof["mesh_coverage"], 25)
            self.assertEqual(len(proof["metrics_sha256"]), 64)

    def test_status_counts_sum(self):
        with tempfile.TemporaryDirectory() as td:
            result = run_demo(self.root, td, 20, 9)
            self.assertEqual(sum(result["metrics"]["statuses"].values()), 20)

    def test_public_critical_never_uses_unlicensed_model(self):
        for w in self.workloads:
            if w.priority_class == "public_critical":
                r = plan_workload(w, self.models, self.resources)
                if r.chosen_plan:
                    model = next(m for m in self.models if m.model_id == r.chosen_plan.model_id)
                    self.assertIn("public_service", model.license_scope)


if __name__ == "__main__":
    unittest.main()

# Threat model

The reference implementation considers:

- resource passport falsification;
- hidden model substitution;
- data-locality laundering;
- energy and carbon telemetry manipulation;
- semantic loss hidden by compression or quantization;
- public-interest priority capture;
- denial of service against public or small-organization workloads;
- correlated node failure;
- vendor lock-in and non-portable runtime dependencies;
- stale model or accelerator capability declarations;
- scheduler objective manipulation;
- fallback plans that reproduce the same failure domain.

Mitigations represented in the MVP include hard filters, separate loss ledgers, Pareto plans, fallback diversity, provenance fields, deterministic receipts and explicit non-goals. Production use requires signed telemetry, live attestation, external audits and adapters maintained by infrastructure owners.

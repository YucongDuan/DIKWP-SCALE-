from __future__ import annotations

import json
from pathlib import Path

from .types import ModelProfile, ResourceNode


def load_resources(path: str | Path) -> list[ResourceNode]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    result = []
    for item in data:
        item["carbon_intensity_by_hour"] = tuple(item["carbon_intensity_by_hour"])
        for key in ("supported_precisions", "runtimes", "capabilities"):
            item[key] = tuple(item[key])
        result.append(ResourceNode(**item))
    return result


def load_models(path: str | Path) -> list[ModelProfile]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    result = []
    for item in data:
        for key in ("modalities", "capabilities", "supported_precisions", "license_scope", "runtime_options"):
            item[key] = tuple(item[key])
        result.append(ModelProfile(**item))
    return result

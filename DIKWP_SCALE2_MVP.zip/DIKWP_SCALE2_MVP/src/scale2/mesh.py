from __future__ import annotations

from itertools import product
from typing import Iterable

from .types import SemanticWorkloadEnvelope

TYPES = ("D", "I", "K", "W", "P")
TRANSFORMATIONS = tuple(f"{a}->{b}" for a, b in product(TYPES, repeat=2))


def coverage() -> dict[str, object]:
    edges = list(TRANSFORMATIONS)
    cycles = []
    for a in TYPES:
        for b in TYPES:
            if a != b:
                cycles.append((f"{a}->{b}", f"{b}->{a}"))
    return {"edges": edges, "coverage": len(edges) / 25.0, "two_cycles": cycles}


def compile_mesh_path(workload: SemanticWorkloadEnvelope) -> tuple[str, ...]:
    """Compile a deterministic, non-hierarchical transformation path.

    The path is indexed by relation kernel and intent fields. All 25 primitive
    transformations are present in the runtime; a workload invokes a rotating
    subset plus explicit feedback cycles.
    """
    seed = sum(ord(ch) for ch in workload.workload_id)
    rotated = list(TRANSFORMATIONS[seed % 25 :] + TRANSFORMATIONS[: seed % 25])
    relation_count = max(5, min(17, len(workload.relation_kernel) + len(workload.intent_fields) * 2))
    selected = rotated[:relation_count]
    # Always include non-linear feedback and purpose revision paths.
    required = ["P->D", "D->P", "W->D", "D->W", "K->I", "I->K", "P->P", "W->P"]
    for edge in required:
        if edge not in selected:
            selected.append(edge)
    return tuple(selected)


def compile_uax(workload: SemanticWorkloadEnvelope) -> tuple[str, ...]:
    residuals: list[str] = []
    if len(workload.observers) > 1:
        residuals.append("UAX-OBSERVER-NONMERGE")
    if workload.semantic_degradation_budget < 0.1:
        residuals.append("UAX-SEMANTIC-COMPRESSION-LIMIT")
    if workload.time_flexible and workload.max_latency_ms < 800:
        residuals.append("UAX-TIME-LATENCY-TENSION")
    if workload.public_interest > 0.7 and workload.privacy_sensitivity > 0.7:
        residuals.append("UAX-PUBLIC-PRIVATE-COUPLING")
    if not residuals:
        residuals.append("UAX-UNNAMED-RELATION-0001")
    return tuple(residuals)


def relation_signatures(workloads: Iterable[SemanticWorkloadEnvelope]) -> dict[str, int]:
    counts: dict[str, int] = {edge: 0 for edge in TRANSFORMATIONS}
    for workload in workloads:
        for edge in compile_mesh_path(workload):
            counts[edge] += 1
    return counts

from __future__ import annotations

import random

from .types import IntentField, SemanticRelation, SemanticWorkloadEnvelope

SCENARIOS = [
    {
        "handle": "health_local_reasoning",
        "regions": ("CN-BEIJING", "CN-SHANGHAI", "CN-GUIZHOU"),
        "modalities": ("text",), "capabilities": ("reasoning", "evidence_trace"),
        "priority": "health_sensitive", "privacy": 0.95, "public": 0.70,
        "latency": 1800.0, "fidelity": 0.83, "resilience": 0.82, "offline": True,
        "flexible": False, "gpu": (0.8, 3.0), "tokens": (0.08, 0.30),
        "intents": (("preserve_data_boundary", "preserve", 1.0), ("preserve_reasoning_trace", "preserve", 0.9)),
        "anti": (("avoid_remote_api_dependence", "repel", 0.95),),
    },
    {
        "handle": "industrial_edge_vision",
        "regions": ("CN-SUZHOU", "CN-SHENZHEN", "CN-WUHAN"),
        "modalities": ("image", "sensor"), "capabilities": ("vision", "edge_inference"),
        "priority": "industrial_realtime", "privacy": 0.70, "public": 0.45,
        "latency": 420.0, "fidelity": 0.75, "resilience": 0.80, "offline": True,
        "flexible": False, "gpu": (0.2, 1.0), "tokens": (0.02, 0.08),
        "intents": (("minimize_latency", "attract", 1.0), ("preserve_fail_safe", "preserve", 0.9)),
        "anti": (("avoid_cloud_roundtrip", "repel", 0.9),),
    },
    {
        "handle": "scientific_batch_discovery",
        "regions": ("CN-BEIJING", "CN-SHANGHAI", "CN-QINGYANG", "CN-GUIZHOU", "CN-HOHHOT"),
        "modalities": ("text", "table"), "capabilities": ("reasoning", "scientific", "long_context"),
        "priority": "research", "privacy": 0.35, "public": 0.80,
        "latency": 12000.0, "fidelity": 0.82, "resilience": 0.70, "offline": False,
        "flexible": True, "gpu": (15.0, 80.0), "tokens": (0.8, 3.0),
        "intents": (("minimize_carbon", "attract", 0.85), ("preserve_hypothesis_plurality", "preserve", 0.8)),
        "anti": (("avoid_premature_answer_collapse", "repel", 0.75),),
    },
    {
        "handle": "public_service_explanation",
        "regions": ("CN-BEIJING", "CN-SHANGHAI", "CN-GUIZHOU", "CN-WUHAN"),
        "modalities": ("text",), "capabilities": ("reasoning", "evidence_trace", "multilingual"),
        "priority": "public_critical", "privacy": 0.82, "public": 1.0,
        "latency": 1600.0, "fidelity": 0.79, "resilience": 0.84, "offline": True,
        "flexible": False, "gpu": (0.3, 1.5), "tokens": (0.10, 0.50),
        "intents": (("expand_public_access", "attract", 1.0), ("preserve_appeal_trace", "preserve", 0.95)),
        "anti": (("avoid_final_denial_automation", "repel", 1.0),),
    },
    {
        "handle": "multilingual_global_public_good",
        "regions": ("CN-SHANGHAI", "CN-GUIZHOU", "SG-SINGAPORE", "EU-FRANKFURT"),
        "modalities": ("text",), "capabilities": ("multilingual", "reasoning"),
        "priority": "public_good", "privacy": 0.35, "public": 1.0,
        "latency": 2600.0, "fidelity": 0.76, "resilience": 0.72, "offline": False,
        "flexible": True, "gpu": (0.4, 4.0), "tokens": (0.25, 1.2),
        "intents": (("expand_public_access", "attract", 0.95), ("preserve_cultural_residuals", "preserve", 0.9)),
        "anti": (("avoid_single_language_projection", "repel", 0.9),),
    },
    {
        "handle": "agent_tool_execution",
        "regions": ("CN-BEIJING", "CN-SHANGHAI", "CN-SHENZHEN"),
        "modalities": ("text",), "capabilities": ("reasoning", "tool_use", "long_context"),
        "priority": "enterprise", "privacy": 0.65, "public": 0.35,
        "latency": 900.0, "fidelity": 0.82, "resilience": 0.88, "offline": False,
        "flexible": False, "gpu": (0.5, 5.0), "tokens": (0.2, 1.0),
        "intents": (("preserve_action_authority", "preserve", 0.95), ("minimize_latency", "attract", 0.7)),
        "anti": (("avoid_permission_drift", "repel", 1.0),),
    },
    {
        "handle": "private_personal_memory",
        "regions": ("CN-BEIJING", "CN-SHANGHAI", "CN-SHENZHEN", "CN-WUHAN"),
        "modalities": ("text", "image"), "capabilities": ("reasoning", "memory"),
        "priority": "personal_private", "privacy": 1.0, "public": 0.15,
        "latency": 2200.0, "fidelity": 0.75, "resilience": 0.72, "offline": True,
        "flexible": False, "gpu": (0.1, 0.8), "tokens": (0.05, 0.25),
        "intents": (("preserve_identity_lineage", "preserve", 1.0),),
        "anti": (("avoid_platform_lockin", "repel", 0.95), ("avoid_remote_api_dependence", "repel", 1.0)),
    },
    {
        "handle": "model_finetune_batch",
        "regions": ("CN-QINGYANG", "CN-GUIZHOU", "CN-HOHHOT", "CN-NINGXIA", "CN-BEIJING"),
        "modalities": ("text", "table"), "capabilities": ("training", "long_context"),
        "priority": "training", "privacy": 0.55, "public": 0.55,
        "latency": 60000.0, "fidelity": 0.70, "resilience": 0.68, "offline": False,
        "flexible": True, "gpu": (100.0, 500.0), "tokens": (8.0, 20.0),
        "intents": (("minimize_carbon", "attract", 1.0), ("preserve_data_boundary", "preserve", 0.8)),
        "anti": (("avoid_peak_power_window", "repel", 0.9),),
    },
]


def _mix(d: float, i: float, k: float, w: float, p: float) -> dict[str, float]:
    return {"D": d, "I": i, "K": k, "W": w, "P": p}


def generate_workloads(count: int = 120, seed: int = 50721) -> list[SemanticWorkloadEnvelope]:
    rng = random.Random(seed)
    workloads = []
    for idx in range(count):
        scenario = SCENARIOS[idx % len(SCENARIOS)]
        workload_id = f"SWE-{idx+1:04d}"
        home = rng.choice(scenario["regions"])
        regions = tuple(dict.fromkeys((home,) + scenario["regions"]))
        observers = ("requester", "affected_party") if scenario["privacy"] > 0.75 else ("requester", "operator", "affected_party")
        relations = []
        relation_names = [
            "preserve_source_trace", "bind_action_to_operator", "keep_data_near_origin",
            "retain_reversible_fallback", "avoid_semantic_projection_loss", "connect_energy_window_to_execution",
            "preserve_observer_disagreement", "carry_uncertainty_into_receipt", "prevent_model_substitution_drift",
            "retain_public_benefit_claim", "couple_failure_to_recovery", "preserve_untranslated_residual",
        ]
        relation_count = 7 + (idx % 6)
        for j in range(relation_count):
            name = relation_names[(idx + j) % len(relation_names)]
            relations.append(SemanticRelation(
                relation_id=f"{workload_id}-R{j+1:02d}",
                source=f"S{(j % 4)+1}", target=f"S{((j+1) % 5)+1}", relation=name,
                observer=observers[j % len(observers)], confidence=round(0.64 + 0.03 * (j % 8), 3),
                dikwp_mix=_mix(0.2 + 0.05*(j%3), 0.2, 0.2, 0.2, 0.2 - 0.05*(j%3)),
                provenance=f"synthetic://{scenario['handle']}/{idx}/{j}",
            ))
        intents = tuple(IntentField(*item, observer="requester") for item in scenario["intents"])
        anti = tuple(IntentField(*item, observer="affected_party") for item in scenario["anti"])
        gpu_hours = rng.uniform(*scenario["gpu"])
        tokens = rng.uniform(*scenario["tokens"])
        budget = 0.07 if scenario["fidelity"] > 0.8 else 0.14
        workloads.append(SemanticWorkloadEnvelope(
            workload_id=workload_id,
            scenario_handle=scenario["handle"],
            observers=observers,
            intent_fields=intents,
            anti_intents=anti,
            relation_kernel=tuple(relations),
            data_regions=(home,),
            permitted_compute_regions=regions,
            forbidden_compute_regions=tuple(r for r in ("US-OREGON", "EU-FRANKFURT") if r not in regions),
            min_memory_gb=24 if gpu_hours < 10 else 80,
            modalities=scenario["modalities"],
            max_latency_ms=scenario["latency"],
            deadline_hours=24.0 if scenario["flexible"] else 1.0,
            time_flexible=scenario["flexible"],
            offline_required=scenario["offline"],
            min_semantic_fidelity=scenario["fidelity"],
            min_resilience=scenario["resilience"],
            public_interest=scenario["public"],
            privacy_sensitivity=scenario["privacy"],
            expected_tokens_million=round(tokens, 4),
            expected_gpu_hours=round(gpu_hours, 4),
            required_capabilities=scenario["capabilities"],
            semantic_degradation_budget=budget,
            priority_class=scenario["priority"],
        ))
    return workloads

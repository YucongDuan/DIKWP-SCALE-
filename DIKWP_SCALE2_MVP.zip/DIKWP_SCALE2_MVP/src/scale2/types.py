from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(frozen=True)
class IntentField:
    name: str
    direction: str  # attract | repel | preserve | explore
    strength: float
    revisable: bool = True
    observer: str = "requester"


@dataclass(frozen=True)
class SemanticRelation:
    relation_id: str
    source: str
    target: str
    relation: str
    observer: str
    confidence: float
    dikwp_mix: dict[str, float]
    provenance: str


@dataclass(frozen=True)
class SemanticWorkloadEnvelope:
    workload_id: str
    scenario_handle: str
    observers: tuple[str, ...]
    intent_fields: tuple[IntentField, ...]
    anti_intents: tuple[IntentField, ...]
    relation_kernel: tuple[SemanticRelation, ...]
    data_regions: tuple[str, ...]
    permitted_compute_regions: tuple[str, ...]
    forbidden_compute_regions: tuple[str, ...]
    min_memory_gb: int
    modalities: tuple[str, ...]
    max_latency_ms: float
    deadline_hours: float
    time_flexible: bool
    offline_required: bool
    min_semantic_fidelity: float
    min_resilience: float
    public_interest: float
    privacy_sensitivity: float
    expected_tokens_million: float
    expected_gpu_hours: float
    required_capabilities: tuple[str, ...]
    semantic_degradation_budget: float
    priority_class: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ResourceNode:
    node_id: str
    region: str
    jurisdiction: str
    owner_type: str
    accelerator: str
    accelerator_count: int
    memory_gb_per_accelerator: int
    throughput_factor: float
    availability: float
    network_latency_ms: float
    base_cost_per_gpu_hour: float
    base_power_kw_per_accelerator: float
    carbon_intensity_by_hour: tuple[float, ...]
    water_intensity_l_per_kwh: float
    supports_offline: bool
    public_quota: float
    domestic_hardware: bool
    supported_precisions: tuple[str, ...]
    runtimes: tuple[str, ...]
    capabilities: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ModelProfile:
    model_id: str
    provider_region: str
    open_weights: bool
    portable: bool
    modalities: tuple[str, ...]
    capabilities: tuple[str, ...]
    base_quality: float
    reliability: float
    context_capacity_million: float
    memory_required_gb: int
    supported_precisions: tuple[str, ...]
    privacy_mode: str
    license_scope: tuple[str, ...]
    runtime_options: tuple[str, ...]
    semantic_strengths: dict[str, float]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class CandidatePlan:
    workload_id: str
    model_id: str
    node_id: str
    execution_hour: int
    precision: str
    semantic_fidelity: float
    latency_ms: float
    cost_units: float
    energy_kwh: float
    carbon_kg: float
    water_l: float
    sovereignty: float
    resilience: float
    public_benefit: float
    semantic_loss: float
    hard_failures: tuple[str, ...] = field(default_factory=tuple)
    loss_ledger: tuple[dict[str, Any], ...] = field(default_factory=tuple)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class AllocationReceipt:
    workload_id: str
    status: str
    chosen_plan: CandidatePlan | None
    pareto_plans: tuple[CandidatePlan, ...]
    rejected_reasons: tuple[str, ...]
    decision_path: tuple[str, ...]
    mesh_transformations: tuple[str, ...]
    uax_residuals: tuple[str, ...]
    fallback_plan: CandidatePlan | None

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        return data

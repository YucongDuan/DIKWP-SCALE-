from __future__ import annotations

import html
import json
from pathlib import Path


def _bar(value: float, maximum: float, width: int = 260) -> str:
    pct = 0 if maximum <= 0 else max(0.0, min(1.0, value / maximum))
    return f'<div class="bar"><span style="width:{pct*100:.1f}%"></span></div>'


def render_dashboard(metrics_path: str | Path, plans_path: str | Path, out_path: str | Path) -> None:
    metrics = json.loads(Path(metrics_path).read_text(encoding="utf-8"))
    strategy = metrics["strategy_summary"]
    max_carbon = max(v["carbon_kg"] for v in strategy.values()) or 1
    max_cost = max(v["cost_units"] for v in strategy.values()) or 1
    rows = []
    for name, data in strategy.items():
        rows.append(f"""
        <tr><td><strong>{html.escape(name)}</strong></td>
        <td>{data['coverage']:.1%}</td><td>{data['semantic_fidelity']:.3f}</td>
        <td>{data['sovereignty']:.3f}</td><td>{data['resilience']:.3f}</td>
        <td>{data['cost_units']:.3f}{_bar(data['cost_units'], max_cost)}</td>
        <td>{data['carbon_kg']:.3f}{_bar(data['carbon_kg'], max_carbon)}</td>
        <td>{int(data['policy_violations'])}</td><td>{int(data['unserved'])}</td></tr>""")
    statuses = "".join(f"<li><b>{html.escape(k)}</b>: {v}</li>" for k, v in metrics["statuses"].items())
    nodes = "".join(f"<tr><td>{html.escape(k)}</td><td>{v}</td></tr>" for k, v in sorted(metrics["node_distribution"].items(), key=lambda x:-x[1]))
    models = "".join(f"<tr><td>{html.escape(k)}</td><td>{v}</td></tr>" for k, v in sorted(metrics["model_distribution"].items(), key=lambda x:-x[1]))
    stress = metrics["stress"]
    doc = f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DIKWP-SCALE² Dashboard</title>
<style>
body{{font-family:system-ui,-apple-system,"Noto Sans CJK SC",sans-serif;background:#f4f6f8;color:#17202a;margin:0}}
header{{background:#123a5a;color:white;padding:28px 6vw}} main{{max-width:1180px;margin:0 auto;padding:24px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}}
.card{{background:white;border-radius:12px;padding:18px;box-shadow:0 2px 10px #0001}}
.big{{font-size:30px;font-weight:750}} table{{width:100%;border-collapse:collapse;background:white}}
th,td{{padding:10px;border-bottom:1px solid #e5e8eb;text-align:left;vertical-align:top}}
th{{background:#eef3f6}} .bar{{height:6px;background:#e8edf0;border-radius:5px;margin-top:4px;overflow:hidden}}
.bar span{{display:block;height:100%;background:#3b82a6}} code{{background:#eef3f6;padding:2px 5px;border-radius:4px}}
.notice{{border-left:4px solid #b36b00;padding:12px;background:#fff7e7}} footer{{padding:30px;color:#5e6d78;text-align:center}}
</style></head><body>
<header><h1>DIKWP-SCALE²</h1><p>无定义意图驱动的数—算—电—网联邦执行与主权调度系统</p><p>Semantic Runtime: {metrics['semantic_runtime']}</p></header>
<main>
<div class="notice">本仪表盘全部使用合成资源、模型、负载、成本、能耗与性能数据。它证明参考调度逻辑可运行，不代表现实集群性能或生产部署资格。</div>
<h2>运行概览</h2><div class="grid">
<div class="card"><div class="big">{metrics['workloads']}</div><div>语义工作负载</div></div>
<div class="card"><div class="big">{metrics['resource_nodes']}</div><div>异构资源节点</div></div>
<div class="card"><div class="big">{metrics['model_profiles']}</div><div>模型执行护照</div></div>
<div class="card"><div class="big">{metrics['mesh_transformations_covered']}/25</div><div>DIKWP×DIKWP覆盖</div></div>
<div class="card"><div class="big">{stress['semantic_budget_compliance_rate']:.1%}</div><div>语义退化预算合规</div></div>
<div class="card"><div class="big">{stress['residency_compliance_rate']:.1%}</div><div>地域与主权约束合规</div></div>
<div class="card"><div class="big">{stress['recovery_target_rate']:.1%}</div><div>可用回退计划比例</div></div>
<div class="card"><div class="big">{stress['time_shifted_workloads']}</div><div>移至低碳时窗负载</div></div>
</div>
<h2>状态</h2><div class="card"><ul>{statuses}</ul></div>
<h2>与操作型基线比较</h2><table><thead><tr><th>策略</th><th>覆盖率</th><th>语义保真</th><th>主权</th><th>韧性</th><th>平均成本</th><th>平均碳排</th><th>政策/地域违例</th><th>未服务</th></tr></thead><tbody>{''.join(rows)}</tbody></table>
<div class="grid" style="margin-top:22px"><div><h2>节点使用</h2><table><tr><th>节点</th><th>计划数</th></tr>{nodes}</table></div><div><h2>模型使用</h2><table><tr><th>模型</th><th>计划数</th></tr>{models}</table></div></div>
<h2>系统边界</h2><div class="card"><ul><li>不控制真实集群、云账户、电网或模型API。</li><li>不以一个总分抵消数据地域、许可、隐私、语义损失或恢复硬约束。</li><li>不为“智能、意识、安全、主权”等概念提供最终定义。</li><li>每个执行计划保留MESH 5.0变换路径、UAX残差和语义损失账本。</li></ul></div>
</main><footer>DIKWP-SCALE² reference demo · Apache-2.0</footer></body></html>"""
    Path(out_path).write_text(doc, encoding="utf-8")

from __future__ import annotations

import hashlib
import math
from collections import Counter
from typing import Iterable

from .mesh import compile_mesh_path, compile_uax
from .types import AllocationReceipt, CandidatePlan, ModelProfile, ResourceNode, SemanticWorkloadEnvelope

PRECISION_FACTOR = {"fp16": 1.0, "bf16": 0.995, "fp8": 0.965, "int8": 0.93, "int4": 0.86}
POWER_FACTOR = {"fp16": 1.0, "bf16": 1.0, "fp8": 0.78, "int8": 0.64, "int4": 0.48}


def _stable_noise(*parts: str, scale: float = 1.0) -> float:
    raw = "|".join(parts).encode("utf-8")
    value = int(hashlib.sha256(raw).hexdigest()[:12], 16) / float(16**12 - 1)
    return (value - 0.5) * 2.0 * scale


def _hard_failures(workload: SemanticWorkloadEnvelope, model: ModelProfile, node: ResourceNode, precision: str) -> list[str]:
    failures: list[str] = []
    if node.region not in workload.permitted_compute_regions:
        failures.append("COMPUTE_REGION_NOT_PERMITTED")
    if node.region in workload.forbidden_compute_regions:
        failures.append("COMPUTE_REGION_FORBIDDEN")
    if workload.offline_required and not node.supports_offline:
        failures.append("OFFLINE_EXECUTION_UNAVAILABLE")
    if not set(workload.modalities).issubset(set(model.modalities)):
        failures.append("MODEL_MODALITY_GAP")
    if not set(workload.required_capabilities).issubset(set(model.capabilities)):
        failures.append("MODEL_CAPABILITY_GAP")
    if not set(workload.required_capabilities).issubset(set(node.capabilities)):
        failures.append("NODE_CAPABILITY_GAP")
    if model.memory_required_gb > node.memory_gb_per_accelerator * max(1, node.accelerator_count):
        failures.append("INSUFFICIENT_ACCELERATOR_MEMORY")
    if precision not in model.supported_precisions or precision not in node.supported_precisions:
        failures.append("PRECISION_UNSUPPORTED")
    if not set(model.runtime_options).intersection(node.runtimes):
        failures.append("RUNTIME_INCOMPATIBLE")
    if workload.privacy_sensitivity >= 0.8 and model.privacy_mode == "remote_api":
        failures.append("PRIVACY_REQUIRES_LOCAL_OR_DEDICATED")
    if workload.priority_class == "public_critical" and "public_service" not in model.license_scope:
        failures.append("MODEL_LICENSE_SCOPE_GAP")
    if workload.data_regions and node.region not in workload.data_regions and workload.privacy_sensitivity >= 0.6:
        failures.append("DATA_RESIDENCY_MISMATCH")
    return failures


def evaluate_candidate(
    workload: SemanticWorkloadEnvelope,
    model: ModelProfile,
    node: ResourceNode,
    precision: str,
    hour: int,
) -> CandidatePlan:
    failures = _hard_failures(workload, model, node, precision)
    context_fit = min(1.0, model.context_capacity_million / max(0.05, workload.expected_tokens_million))
    modality_fit = len(set(workload.modalities).intersection(model.modalities)) / max(1, len(workload.modalities))
    capability_fit = len(set(workload.required_capabilities).intersection(model.capabilities)) / max(1, len(workload.required_capabilities))
    relation_complexity = min(1.0, 0.55 + 0.035 * len(workload.relation_kernel))
    intent_alignment = sum(i.strength for i in workload.intent_fields if i.direction in {"attract", "preserve"})
    anti_intent_pressure = sum(i.strength for i in workload.anti_intents)
    semantic_specialization = 0.0
    for capability in workload.required_capabilities:
        semantic_specialization += model.semantic_strengths.get(capability, model.base_quality)
    semantic_specialization /= max(1, len(workload.required_capabilities))

    precision_loss = 1.0 - PRECISION_FACTOR[precision]
    protocol_loss = max(0.0, 0.015 * (len(workload.observers) - 1))
    remote_loss = 0.025 if workload.data_regions and node.region not in workload.data_regions else 0.0
    decomposition_loss = max(0.0, 0.01 * (len(workload.relation_kernel) - 8))
    semantic_loss = min(0.45, precision_loss + protocol_loss + remote_loss + decomposition_loss)

    semantic_fidelity = (
        0.28 * model.base_quality
        + 0.18 * model.reliability
        + 0.16 * context_fit
        + 0.12 * modality_fit
        + 0.12 * capability_fit
        + 0.08 * semantic_specialization
        + 0.06 * relation_complexity
        + 0.01 * min(1.0, intent_alignment)
        - 0.01 * min(1.0, anti_intent_pressure)
        - semantic_loss
        + _stable_noise(workload.workload_id, model.model_id, node.node_id, precision, scale=0.012)
    )
    semantic_fidelity = max(0.0, min(1.0, semantic_fidelity))

    throughput = max(0.1, node.throughput_factor * node.accelerator_count * (1.0 / POWER_FACTOR[precision]))
    compute_hours = max(0.02, workload.expected_gpu_hours / throughput)
    latency_ms = node.network_latency_ms + 230.0 / max(0.2, node.throughput_factor) + 28.0 * workload.expected_tokens_million
    if node.region not in workload.data_regions and workload.data_regions:
        latency_ms += 80.0
    latency_ms *= 1.0 + max(0.0, workload.privacy_sensitivity - 0.7) * 0.15

    energy_kwh = compute_hours * node.base_power_kw_per_accelerator * max(1, min(node.accelerator_count, math.ceil(model.memory_required_gb / node.memory_gb_per_accelerator))) * POWER_FACTOR[precision]
    carbon_intensity = node.carbon_intensity_by_hour[hour % 24]
    carbon_kg = energy_kwh * carbon_intensity
    water_l = energy_kwh * node.water_intensity_l_per_kwh
    cost_units = compute_hours * node.base_cost_per_gpu_hour * (1.0 + (0.12 if model.open_weights is False else 0.0))

    sovereignty = 1.0
    if workload.data_regions and node.region not in workload.data_regions:
        sovereignty -= 0.35
    if not model.open_weights and workload.privacy_sensitivity > 0.5:
        sovereignty -= 0.2
    if node.jurisdiction != "CN" and workload.priority_class in {"public_critical", "health_sensitive"}:
        sovereignty -= 0.3
    sovereignty = max(0.0, sovereignty)

    portability = 1.0 if model.portable else 0.55
    domestic_bonus = 0.08 if node.domestic_hardware else 0.0
    resilience = min(1.0, 0.55 * node.availability + 0.25 * model.reliability + 0.12 * portability + domestic_bonus)
    public_benefit = min(1.0, 0.45 * node.public_quota + 0.35 * workload.public_interest + 0.2 * (1.0 if model.open_weights else 0.4))

    ledger = (
        {"source": "precision", "loss": round(precision_loss, 5), "reversible": True},
        {"source": "multi_observer_projection", "loss": round(protocol_loss, 5), "reversible": False},
        {"source": "data_locality_bridge", "loss": round(remote_loss, 5), "reversible": True},
        {"source": "task_decomposition", "loss": round(decomposition_loss, 5), "reversible": True},
    )

    return CandidatePlan(
        workload_id=workload.workload_id,
        model_id=model.model_id,
        node_id=node.node_id,
        execution_hour=hour,
        precision=precision,
        semantic_fidelity=round(semantic_fidelity, 6),
        latency_ms=round(latency_ms, 3),
        cost_units=round(cost_units, 5),
        energy_kwh=round(energy_kwh, 5),
        carbon_kg=round(carbon_kg, 5),
        water_l=round(water_l, 5),
        sovereignty=round(sovereignty, 6),
        resilience=round(resilience, 6),
        public_benefit=round(public_benefit, 6),
        semantic_loss=round(semantic_loss, 6),
        hard_failures=tuple(failures),
        loss_ledger=ledger,
    )


def _dominates(a: CandidatePlan, b: CandidatePlan) -> bool:
    # Maximize first four, minimize next four. No scalar collapse.
    better_or_equal = (
        a.semantic_fidelity >= b.semantic_fidelity
        and a.sovereignty >= b.sovereignty
        and a.resilience >= b.resilience
        and a.public_benefit >= b.public_benefit
        and a.latency_ms <= b.latency_ms
        and a.cost_units <= b.cost_units
        and a.carbon_kg <= b.carbon_kg
        and a.semantic_loss <= b.semantic_loss
    )
    strictly_better = (
        a.semantic_fidelity > b.semantic_fidelity
        or a.sovereignty > b.sovereignty
        or a.resilience > b.resilience
        or a.public_benefit > b.public_benefit
        or a.latency_ms < b.latency_ms
        or a.cost_units < b.cost_units
        or a.carbon_kg < b.carbon_kg
        or a.semantic_loss < b.semantic_loss
    )
    return better_or_equal and strictly_better


def pareto_frontier(candidates: Iterable[CandidatePlan]) -> list[CandidatePlan]:
    items = [c for c in candidates if not c.hard_failures]
    frontier: list[CandidatePlan] = []
    for candidate in items:
        if any(_dominates(other, candidate) for other in items if other is not candidate):
            continue
        frontier.append(candidate)
    return sorted(frontier, key=lambda p: (-p.semantic_fidelity, p.carbon_kg, p.cost_units, p.latency_ms))


def _choose(frontier: list[CandidatePlan], workload: SemanticWorkloadEnvelope) -> CandidatePlan | None:
    if not frontier:
        return None
    # Intent-indexed lexicographic path. Purpose is revisable and not a global scalar.
    directions = {i.name: i.strength for i in workload.intent_fields}
    if workload.priority_class in {"public_critical", "health_sensitive"}:
        key = lambda p: (-p.sovereignty, -p.semantic_fidelity, -p.resilience, p.latency_ms, p.cost_units)
    elif directions.get("minimize_carbon", 0.0) >= 0.7 or workload.time_flexible:
        key = lambda p: (p.carbon_kg, -p.semantic_fidelity, p.cost_units, -p.resilience, p.latency_ms)
    elif directions.get("minimize_latency", 0.0) >= 0.7:
        key = lambda p: (p.latency_ms, -p.semantic_fidelity, -p.resilience, p.cost_units, p.carbon_kg)
    elif directions.get("expand_public_access", 0.0) >= 0.7:
        key = lambda p: (-p.public_benefit, -p.semantic_fidelity, p.cost_units, -p.sovereignty, p.carbon_kg)
    else:
        key = lambda p: (-p.semantic_fidelity, p.cost_units, p.carbon_kg, -p.resilience, p.latency_ms)
    return sorted(frontier, key=key)[0]


def plan_workload(
    workload: SemanticWorkloadEnvelope,
    models: list[ModelProfile],
    nodes: list[ResourceNode],
) -> AllocationReceipt:
    candidates: list[CandidatePlan] = []
    hours = range(24) if workload.time_flexible else (12,)
    for model in models:
        for node in nodes:
            for precision in ("fp16", "bf16", "fp8", "int8", "int4"):
                if precision not in model.supported_precisions or precision not in node.supported_precisions:
                    continue
                best_hour = min(hours, key=lambda h: node.carbon_intensity_by_hour[h]) if workload.time_flexible else 12
                candidates.append(evaluate_candidate(workload, model, node, precision, best_hour))

    feasible = [c for c in candidates if not c.hard_failures]
    # Semantic and resilience hard gates are evaluated after physical feasibility.
    qualified = [
        c for c in feasible
        if c.semantic_fidelity >= workload.min_semantic_fidelity
        and c.resilience >= workload.min_resilience
        and c.semantic_loss <= workload.semantic_degradation_budget
        and c.latency_ms <= workload.max_latency_ms
    ]
    frontier = pareto_frontier(qualified)
    chosen = _choose(frontier, workload)
    fallback_candidates = [c for c in feasible if c.semantic_fidelity >= workload.min_semantic_fidelity - 0.08]
    fallback_frontier = pareto_frontier(fallback_candidates)
    fallback = None
    if chosen:
        alternatives = [p for p in fallback_frontier if p.node_id != chosen.node_id or p.model_id != chosen.model_id]
        fallback = sorted(alternatives, key=lambda p: (-p.resilience, -p.sovereignty, p.cost_units))[0] if alternatives else None
    elif fallback_frontier:
        fallback = sorted(fallback_frontier, key=lambda p: (-p.resilience, -p.semantic_fidelity, p.cost_units))[0]

    reason_counts = Counter(r for c in candidates for r in c.hard_failures)
    rejected = tuple(f"{name}:{count}" for name, count in reason_counts.most_common(12))
    status = "ALLOCATED" if chosen else ("HOLD_FOR_REVIEW" if fallback else "UNSCHEDULABLE")
    decision_path = (
        "compile_intent_field_without_concept_definition",
        "run_full_DIKWPxDIKWP_runtime",
        "filter_nonnegotiable_locality_capability_and_license_relations",
        "preserve_semantic_degradation_budget",
        "construct_multiobjective_pareto_frontier",
        "apply_intent_indexed_lexicographic_selection",
        "attach_fallback_and_recovery_path",
    )
    return AllocationReceipt(
        workload_id=workload.workload_id,
        status=status,
        chosen_plan=chosen,
        pareto_plans=tuple(frontier[:15]),
        rejected_reasons=rejected,
        decision_path=decision_path,
        mesh_transformations=compile_mesh_path(workload),
        uax_residuals=compile_uax(workload),
        fallback_plan=fallback,
    )


def baseline_plan(
    workload: SemanticWorkloadEnvelope,
    models: list[ModelProfile],
    nodes: list[ResourceNode],
    strategy: str,
) -> CandidatePlan | None:
    # Deliberately operational baselines: they enforce basic model/hardware compatibility,
    # but not the complete semantic, locality and public-interest gates.
    candidates: list[CandidatePlan] = []
    for model in models:
        for node in nodes:
            for precision in ("fp16", "fp8", "int8"):
                if precision not in model.supported_precisions or precision not in node.supported_precisions:
                    continue
                c = evaluate_candidate(workload, model, node, precision, 12)
                basic_failures = set(c.hard_failures) - {
                    "COMPUTE_REGION_NOT_PERMITTED", "COMPUTE_REGION_FORBIDDEN",
                    "DATA_RESIDENCY_MISMATCH", "PRIVACY_REQUIRES_LOCAL_OR_DEDICATED",
                    "MODEL_LICENSE_SCOPE_GAP", "OFFLINE_EXECUTION_UNAVAILABLE",
                }
                if not basic_failures:
                    candidates.append(c)
    if not candidates:
        return None
    if strategy == "cost_only":
        return min(candidates, key=lambda c: (c.cost_units, c.latency_ms))
    if strategy == "latency_only":
        return min(candidates, key=lambda c: (c.latency_ms, c.cost_units))
    if strategy == "carbon_only":
        return min(candidates, key=lambda c: (c.carbon_kg, c.cost_units))
    if strategy == "quality_only":
        return max(candidates, key=lambda c: (c.semantic_fidelity, -c.cost_units))
    index = int(hashlib.sha256((workload.workload_id + strategy).encode()).hexdigest()[:8], 16) % len(candidates)
    return sorted(candidates, key=lambda c: (c.node_id, c.model_id, c.precision))[index]

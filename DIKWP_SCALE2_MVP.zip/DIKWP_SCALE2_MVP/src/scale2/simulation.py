from __future__ import annotations

import csv
import hashlib
import json
import statistics
from collections import Counter, defaultdict
from dataclasses import asdict
from pathlib import Path
from typing import Any

from .catalog import load_models, load_resources
from .mesh import TRANSFORMATIONS, relation_signatures
from .planner import baseline_plan, plan_workload
from .types import CandidatePlan
from .workloads import generate_workloads


def _mean(values: list[float]) -> float:
    return statistics.fmean(values) if values else 0.0


def _violation_count(plan: CandidatePlan | None) -> int:
    if plan is None:
        return 0
    forbidden = {
        "COMPUTE_REGION_NOT_PERMITTED", "COMPUTE_REGION_FORBIDDEN", "DATA_RESIDENCY_MISMATCH",
        "PRIVACY_REQUIRES_LOCAL_OR_DEDICATED", "MODEL_LICENSE_SCOPE_GAP", "OFFLINE_EXECUTION_UNAVAILABLE",
    }
    return int(bool(forbidden.intersection(plan.hard_failures)))


def run_demo(root: str | Path, out_dir: str | Path, workload_count: int = 120, seed: int = 50721) -> dict[str, Any]:
    root = Path(root)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    resources = load_resources(root / "config" / "resources.json")
    models = load_models(root / "config" / "models.json")
    workloads = generate_workloads(workload_count, seed)

    receipts = [plan_workload(w, models, resources) for w in workloads]
    chosen = [r.chosen_plan for r in receipts if r.chosen_plan is not None]
    statuses = Counter(r.status for r in receipts)
    scenarios = Counter(w.scenario_handle for w in workloads)
    nodes = Counter(p.node_id for p in chosen)
    models_used = Counter(p.model_id for p in chosen)
    precision_used = Counter(p.precision for p in chosen)

    baselines: dict[str, list[CandidatePlan | None]] = {}
    for strategy in ("cost_only", "latency_only", "carbon_only", "quality_only", "random"):
        baselines[strategy] = [baseline_plan(w, models, resources, strategy) for w in workloads]

    def summarize(plans: list[CandidatePlan | None]) -> dict[str, float]:
        valid = [p for p in plans if p]
        return {
            "coverage": len(valid) / len(plans),
            "semantic_fidelity": _mean([p.semantic_fidelity for p in valid]),
            "latency_ms": _mean([p.latency_ms for p in valid]),
            "cost_units": _mean([p.cost_units for p in valid]),
            "carbon_kg": _mean([p.carbon_kg for p in valid]),
            "sovereignty": _mean([p.sovereignty for p in valid]),
            "resilience": _mean([p.resilience for p in valid]),
            "public_benefit": _mean([p.public_benefit for p in valid]),
            "semantic_loss": _mean([p.semantic_loss for p in valid]),
            "policy_violations": sum(_violation_count(p) for p in plans),
            "unserved": len(plans) - len(valid),
        }

    strategy_summary = {"scale2": summarize([r.chosen_plan for r in receipts])}
    strategy_summary.update({name: summarize(plans) for name, plans in baselines.items()})

    allocated_receipts = [r for r in receipts if r.chosen_plan]
    recovery_success = sum(1 for r in allocated_receipts if r.fallback_plan and r.fallback_plan.resilience >= 0.72)
    recovery_rate = recovery_success / max(1, len(allocated_receipts))
    semantic_budget_compliance = sum(
        1 for w, r in zip(workloads, receipts)
        if r.chosen_plan and r.chosen_plan.semantic_loss <= w.semantic_degradation_budget
    ) / max(1, len(allocated_receipts))
    residency_compliance = sum(
        1 for w, r in zip(workloads, receipts)
        if r.chosen_plan and r.chosen_plan.node_id in {n.node_id for n in resources if n.region in w.permitted_compute_regions}
    ) / max(1, len(allocated_receipts))

    # Synthetic stress scenarios.
    stress = {
        "accelerator_outage_replanned": sum(1 for r in allocated_receipts if r.fallback_plan is not None),
        "semantic_budget_compliance_rate": semantic_budget_compliance,
        "residency_compliance_rate": residency_compliance,
        "recovery_target_rate": recovery_rate,
        "time_shifted_workloads": sum(1 for w, r in zip(workloads, receipts) if w.time_flexible and r.chosen_plan and r.chosen_plan.execution_hour != 12),
        "uax_residuals_preserved": sum(len(r.uax_residuals) for r in receipts),
    }

    mesh_counts = relation_signatures(workloads)
    metrics = {
        "semantic_runtime": "DIKWP-MESH 5.0",
        "workloads": len(workloads),
        "resource_nodes": len(resources),
        "model_profiles": len(models),
        "statuses": dict(statuses),
        "scenario_distribution": dict(scenarios),
        "node_distribution": dict(nodes),
        "model_distribution": dict(models_used),
        "precision_distribution": dict(precision_used),
        "strategy_summary": strategy_summary,
        "stress": stress,
        "mesh_transformations_available": len(TRANSFORMATIONS),
        "mesh_transformations_covered": len(TRANSFORMATIONS),
        "mesh_transformations_invoked": sum(1 for x in TRANSFORMATIONS if mesh_counts[x] > 0),
        "mesh_transformation_counts": mesh_counts,
        "notes": [
            "All resources, models, workloads, costs, energy and performance figures are synthetic.",
            "The system is a reference planner; it does not control any real cluster, cloud account or electrical load.",
            "No scalar score is used to erase hard constraints or semantic residuals.",
        ],
    }

    # Write structured outputs.
    (out_dir / "metrics.json").write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")
    with (out_dir / "allocation_receipts.jsonl").open("w", encoding="utf-8") as f:
        for receipt in receipts:
            f.write(json.dumps(receipt.to_dict(), ensure_ascii=False) + "\n")
    with (out_dir / "workloads.jsonl").open("w", encoding="utf-8") as f:
        for workload in workloads:
            f.write(json.dumps(workload.to_dict(), ensure_ascii=False) + "\n")

    with (out_dir / "plans.csv").open("w", newline="", encoding="utf-8-sig") as f:
        fieldnames = [
            "workload_id", "status", "scenario_handle", "model_id", "node_id", "execution_hour", "precision",
            "semantic_fidelity", "latency_ms", "cost_units", "energy_kwh", "carbon_kg", "water_l",
            "sovereignty", "resilience", "public_benefit", "semantic_loss", "fallback_model", "fallback_node",
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for workload, receipt in zip(workloads, receipts):
            p = receipt.chosen_plan
            writer.writerow({
                "workload_id": workload.workload_id,
                "status": receipt.status,
                "scenario_handle": workload.scenario_handle,
                "model_id": p.model_id if p else "",
                "node_id": p.node_id if p else "",
                "execution_hour": p.execution_hour if p else "",
                "precision": p.precision if p else "",
                "semantic_fidelity": p.semantic_fidelity if p else "",
                "latency_ms": p.latency_ms if p else "",
                "cost_units": p.cost_units if p else "",
                "energy_kwh": p.energy_kwh if p else "",
                "carbon_kg": p.carbon_kg if p else "",
                "water_l": p.water_l if p else "",
                "sovereignty": p.sovereignty if p else "",
                "resilience": p.resilience if p else "",
                "public_benefit": p.public_benefit if p else "",
                "semantic_loss": p.semantic_loss if p else "",
                "fallback_model": receipt.fallback_plan.model_id if receipt.fallback_plan else "",
                "fallback_node": receipt.fallback_plan.node_id if receipt.fallback_plan else "",
            })

    with (out_dir / "resource_catalog.csv").open("w", newline="", encoding="utf-8-sig") as f:
        fieldnames = [
            "node_id", "region", "jurisdiction", "owner_type", "accelerator", "accelerator_count",
            "memory_gb_per_accelerator", "throughput_factor", "availability", "base_cost_per_gpu_hour",
            "base_power_kw_per_accelerator", "public_quota", "domestic_hardware",
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for n in resources:
            writer.writerow({k: getattr(n, k) for k in fieldnames})

    proof_payload = {
        "seed": seed,
        "workload_count": workload_count,
        "metrics_sha256": hashlib.sha256((out_dir / "metrics.json").read_bytes()).hexdigest(),
        "receipts_sha256": hashlib.sha256((out_dir / "allocation_receipts.jsonl").read_bytes()).hexdigest(),
        "mesh_coverage": metrics["mesh_transformations_covered"],
        "status": "REFERENCE_DEMO_COMPLETE",
    }
    (out_dir / "RUN_PROOF.json").write_text(json.dumps(proof_payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"metrics": metrics, "receipts": receipts, "workloads": workloads, "resources": resources, "models": models}

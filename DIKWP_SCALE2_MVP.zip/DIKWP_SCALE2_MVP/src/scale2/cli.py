from __future__ import annotations

import argparse
import json
from pathlib import Path

from .dashboard import render_dashboard
from .simulation import run_demo


def main() -> None:
    parser = argparse.ArgumentParser(prog="dikwp-scale2")
    sub = parser.add_subparsers(dest="command", required=True)
    demo = sub.add_parser("demo", help="run deterministic synthetic demonstration")
    demo.add_argument("--root", default=".")
    demo.add_argument("--out", default="outputs")
    demo.add_argument("--workloads", type=int, default=120)
    demo.add_argument("--seed", type=int, default=50721)
    args = parser.parse_args()
    if args.command == "demo":
        result = run_demo(args.root, args.out, args.workloads, args.seed)
        out = Path(args.out)
        render_dashboard(out / "metrics.json", out / "plans.csv", out / "dashboard.html")
        print(json.dumps({
            "status": "REFERENCE_DEMO_COMPLETE",
            "workloads": result["metrics"]["workloads"],
            "allocated": result["metrics"]["statuses"].get("ALLOCATED", 0),
            "mesh_coverage": result["metrics"]["mesh_transformations_covered"],
            "dashboard": str(out / "dashboard.html"),
        }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

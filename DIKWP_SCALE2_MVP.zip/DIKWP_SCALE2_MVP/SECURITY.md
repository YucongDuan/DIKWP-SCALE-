# Security policy

Report vulnerabilities privately to the designated security maintainers before public disclosure. Do not include production credentials, personal data, cluster topology secrets or live power-system information in reports.

This repository is a synthetic reference implementation and has no production security certification.

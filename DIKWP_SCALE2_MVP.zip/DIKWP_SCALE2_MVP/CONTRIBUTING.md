# Contributing

Contributions are welcome through issues and pull requests. Please include tests, describe semantic-loss implications, state which observers and deployment contexts are affected, and avoid introducing a single scalar score that can override hard constraints.
